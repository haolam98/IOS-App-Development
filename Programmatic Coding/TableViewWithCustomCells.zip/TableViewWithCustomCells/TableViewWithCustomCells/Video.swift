//
//  Video.swift
//  TableViewWithCustomCells
//
//  Created by Hao Lam on 7/1/20.
//  Copyright © 2020 Hao Lam. All rights reserved.
//

import UIKit

struct Video{
    var image:UIImage
    var title: String
}
