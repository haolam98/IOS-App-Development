//
//  DummyController.swift
//  halloweenTabBar
//
//  Created by Hao Lam on 7/1/20.
//  Copyright © 2020 Hao Lam. All rights reserved.
//


import UIKit
import TinyConstraints
class DummyController: UIViewController {
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        //add background
        view.backgroundColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        
    
    }


}


